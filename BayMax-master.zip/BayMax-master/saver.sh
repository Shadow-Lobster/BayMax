#!/bin/bash
while true
do
./bot.sh
sleep 1
done
