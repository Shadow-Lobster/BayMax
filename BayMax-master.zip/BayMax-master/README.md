# BashBot
-------------------------------------------------------------------------------------------------------------------------------
This Irc Bash Bot is a stripped down code of Megatron. Megatron is my bot that is on EvilCorp in #lobby. https://triplezer0.hugoslop.repl.co/mega.html
This Bot requires u to have a passworded nick.
The bot.sh is setup to ssl port 6697. YAY!
# Configuring
simply edit bot.properties
# Running
1. Open on the file directory in which u put the files.
2. chmod +x bot.sh
